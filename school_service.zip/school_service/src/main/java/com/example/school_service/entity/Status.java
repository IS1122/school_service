package com.example.school_service.entity;

public enum Status {
    OPEN,CLOSED
}
