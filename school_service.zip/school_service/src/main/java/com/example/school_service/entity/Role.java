package com.example.school_service.entity;

public enum Role {
    ADMIN, USER
}
